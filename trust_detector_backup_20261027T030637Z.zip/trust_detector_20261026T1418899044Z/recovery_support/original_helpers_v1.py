def index_tokens(text):
    return [
        word
        for word in re.findall(r"[a-z0-9]+", text.lower())
        if word not in INDEX_STOPWORDS
    ]

def index_vector(text, idf):
    counts = Counter(index_tokens(text))

    weights = {
        word: (1 + math.log(count)) * idf[word]
        for word, count in counts.items()
        if word in idf
    }

    length = math.sqrt(sum(value ** 2 for value in weights.values()))

    return (
        {word: value / length for word, value in weights.items()}
        if length else {}
    )

def integration_retrieve(question, database_path, top_k=3):
    assert top_k > 0

    with sqlite3.connect(
        database_path.resolve().as_uri() + "?mode=ro",
        uri=True,
    ) as connection:
        idf = json.loads(
            connection.execute(
                "SELECT value_json FROM settings WHERE name = 'idf'"
            ).fetchone()[0]
        )

        rows = connection.execute(
            "SELECT payload_json, vector_json FROM passages"
        ).fetchall()

    query_vector = index_vector(question, idf)
    matches = []

    for payload_json, vector_json in rows:
        passage = json.loads(payload_json)
        vector = json.loads(vector_json)

        score = sum(
            weight * vector.get(word, 0)
            for word, weight in query_vector.items()
        )

        if score > 0:
            matches.append({**passage, "score": score})

    return sorted(
        matches,
        key=lambda passage: (
            -passage["score"],
            passage["passage_id"],
        ),
    )[:top_k]

def sentence_candidates(text):
    candidates = []

    for paragraph in text.split("\n\n"):
        for sentence in re.split(r"(?<=[.!?])\s+", paragraph):
            sentence = sentence.strip()

            # Exclude questions, short headings, and incomplete fragments.
            if (
                sentence.endswith((".", "!"))
                and len(index_tokens(sentence)) >= 5
            ):
                candidates.append(sentence)

    return candidates

def select_probe_sentence(question, passage_text, idf):
    candidates = sentence_candidates(passage_text)

    if not candidates:
        return None

    question_vector = index_vector(question, idf)

    def score(sentence):
        vector = index_vector(sentence, idf)

        return sum(
            weight * vector.get(word, 0)
            for word, weight in question_vector.items()
        )

    # Earlier sentences break equal-score ties.
    ranked = sorted(
        enumerate(candidates),
        key=lambda item: (-score(item[1]), item[0]),
    )

    return ranked[0][1]

def relation_margins(relation):
    scores = relation["scores"]

    support = max(
        0.0,
        scores["entailment"] - max(
            scores["contradiction"],
            scores["neutral"],
        ),
    )

    contradiction = max(
        0.0,
        scores["contradiction"] - max(
            scores["entailment"],
            scores["neutral"],
        ),
    )

    return support, contradiction

def calculate_ablation_scores(assessment):
    P = assessment["provenance"]["provenance_score"]

    aggregation = assessment["margin_aggregation"]
    S = aggregation["support_score"]
    C = aggregation["contradiction_score"]

    if S is None or C is None:
        full_score = P
        constant_prior_score = 0.5
    else:
        full_score = P * (1 - C) + (1 - P) * S

        # Remove source-origin preference.
        constant_prior_score = 0.5 * (1 - C) + 0.5 * S

    assert math.isclose(
        full_score,
        assessment["trust_score"],
        abs_tol=1e-8,
    )

    # Comparison baseline: give each passage an equal vote,
    # rather than grouping it with passages from the same family.
    margins = [
        relation_margins(relation)
        for relation in assessment["raw_relations"]
    ]

    if margins:
        passage_support = sum(
            support for support, _ in margins
        ) / len(margins)

        passage_contradiction = sum(
            contradiction for _, contradiction in margins
        ) / len(margins)

        passage_average_score = (
            P * (1 - passage_contradiction)
            + (1 - P) * passage_support
        )
    else:
        passage_average_score = P

    return {
        "full_detector": full_score,
        "provenance_only": P,
        "constant_prior": constant_prior_score,
        "passage_average_without_family_grouping": (
            passage_average_score
        ),
    }

def build_answer_messages(question, context):
    evidence_text = "\n\n".join(
        f"[{passage['passage_id']}]\n{passage['text']}"
        for passage in context
    )

    return [
        {
            "role": "system",
            "content": QWEN_PLAN["system_prompt"],
        },
        {
            "role": "user",
            "content": (
                f"EVIDENCE:\n{evidence_text}\n\n"
                f"QUESTION:\n{question}"
            ),
        },
    ]

def answer_prompt_key(messages):
    # Key represents model inputs and declared generation settings.
    payload = {
        "model": QWEN_PLAN["model"],
        "model_revision": QWEN_PLAN["model_revision"],
        "messages": messages,
        "max_new_tokens": QWEN_PLAN["max_new_tokens"],
        "do_sample": QWEN_PLAN["do_sample"],
        "dtype": QWEN_PLAN["dtype"],
        "default_generation_configuration": (
            QWEN_DEFAULT_GENERATION_CONFIG
        ),
    }

    return hashlib.sha256(
        json.dumps(
            payload,
            sort_keys=True,
            ensure_ascii=False,
        ).encode("utf-8")
    ).hexdigest()

def generate_cached_answer(group, cache):
    key = group["prompt_key"]

    assert answer_prompt_key(group["messages"]) == key

    if key in cache:
        record = cache[key]

        assert record["messages"] == group["messages"]
        assert hashlib.sha256(
            record["answer"].encode("utf-8")
        ).hexdigest() == record["answer_sha256"]

        return record, True

    assert "qwen_model" in globals(), (
        "The Qwen model is no longer loaded. "
        "Stop and share this message; do not rerun all earlier cells."
    )

    prompt_text = qwen_tokenizer.apply_chat_template(
        group["messages"],
        tokenize=False,
        add_generation_prompt=True,
    )

    inputs = qwen_tokenizer(
        prompt_text,
        return_tensors="pt",
        add_special_tokens=False,
        truncation=False,
    ).to("cpu")

    prompt_tokens = inputs["input_ids"].shape[1]
    max_new_tokens = QWEN_PLAN["max_new_tokens"]

    assert prompt_tokens + max_new_tokens <= (
        qwen_model.config.max_position_embeddings
    )

    start = time.perf_counter()

    with torch.inference_mode():
        generated = qwen_model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            pad_token_id=qwen_tokenizer.eos_token_id,
        )

    elapsed = time.perf_counter() - start
    answer_tokens = generated[0, prompt_tokens:]

    answer = qwen_tokenizer.decode(
        answer_tokens,
        skip_special_tokens=True,
    ).strip()

    record = {
        "prompt_key": key,
        "messages": group["messages"],
        "answer": answer,
        "answer_sha256": hashlib.sha256(
            answer.encode("utf-8")
        ).hexdigest(),
        "prompt_token_count": prompt_tokens,
        "generated_token_count": len(answer_tokens),
        "generation_seconds": elapsed,
        "reached_token_limit": len(answer_tokens) == max_new_tokens,
        "model": QWEN_PLAN["model"],
        "model_revision": QWEN_PLAN["model_revision"],
        "cpu_threads": torch.get_num_threads(),
        "torch_version": torch.__version__,
        "transformers_version": transformers.__version__,
    }

    cache[key] = record

    temporary_path = QWEN_CACHE_PATH.with_suffix(".tmp")
    temporary_path.write_text(
        json.dumps(cache, indent=2),
        encoding="utf-8",
    )
    temporary_path.replace(QWEN_CACHE_PATH)

    return record, False

def save_matching_json(path, value):
    """Create a file, or verify that an existing file matches."""
    if path.exists():
        assert json.loads(path.read_text(encoding="utf-8")) == value, (
            f"Existing file differs: {path}"
        )
    else:
        path.write_text(
            json.dumps(value, indent=2), encoding="utf-8"
        )

def normalized_passage_text(text):
    # Match the earlier exact-deduplication rule.
    return " ".join(text.lower().split())
